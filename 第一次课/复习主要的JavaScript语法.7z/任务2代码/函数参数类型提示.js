/**
 *
 * @param p1 {float}
 * @param p2 {string}
 * @param p3 {int}
 * @return {string}
 */
let f1 = function (p1, p2, p3) {
    // console.log('参数类型提示')
    return 'hello'
}

f1(1.0,'world',5);

class Person{
    name = '';
    age = 0;

    /**
     *
     * @param name {string}
     * @param age {int}
     */
    constructor(name,age) {
        this.name = name;
        this.age = age;
    }

    /**
     * @type {string} 静态成员变量
     */
    static p1;

    /**
     *
     * @param a {string}
     * @param b {int}
     */
    f1(a,b){
        console.log('this中的值:' + this.name + this.age);
    }
}

let baJie = new Person('八戒',200);
console.log(baJie.name);
baJie.f1(1,2);


