let i = true

if (i === true){
    console.log('yes')
}

// while (i){
//     setTimeout(() => { console.log("World!"); }, 5000);
// }

console.log("Hello");
setTimeout(() => { console.log("World!"); }, 5000);
console.log("Goodbye!");