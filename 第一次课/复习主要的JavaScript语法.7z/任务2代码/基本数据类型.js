/**
 * JavaScript has 8 Datatypes
 * 1. String
 * 2. Number
 * 3. Bigint
 * 4. Boolean
 * 5. Undefined
 * 6. Null
 * 7. Symbol
 * 8. Object
 *
 * The Object Datatype
 * The object data type can contain:
 *
 * 1. An object
 * 2. An array
 * 3. A date
 *
 * ------------------------------------------------
 *
 * Examples
 * // Numbers:
 * let length = 16;
 * let weight = 7.5;
 *
 * // Strings:
 * let color = "Yellow";
 * let lastName = "Johnson";
 *
 * // Booleans
 * let x = true;
 * let y = false;
 *
 * // Object:
 * const person = {firstName:"John", lastName:"Doe"};
 *
 * // Array object:
 * const cars = ["Saab", "Volvo", "BMW"];
 *
 * // Date object:
 * const date = new Date("2022-03-25");
 */

let f = false;
// var s = 'hello'
let i = 1;

let j = `i的值是"${i}"`;  // ``是模板语法，也可以使字符串换行
console.log(j)

// ``可以换行  '' ""不能换行
console.log(typeof `c
    dwadwlad
`)
/*

console.log(f+i);
console.log('hello' + 5);
console.log('hello' + true);
console.log('hello' * 5);

// 字串
console.log('"hello wolrd" + "\"');
console.log(`world`);
let s = ' hello world';
console.log(s.substring(1,5))
console.log(s.toUpperCase());
console.log(s.charAt(0));
console.log(s.length)
console.log(s.concat(' world'))
console.log(s.concat(['hlloe','c','k']))
console.log(s.includes('he'))
console.log(s.includes('he',0));
console.log(s.split(' '))
console.log(s.trim())*/

// 用户输入
// let username = prompt('轻输入账号');

// 数组矩阵
let arr = [5, 4, 7, 10];
console.log(arr)
for (let j = 0; j < arr.length; j++) {
    console.log(arr[j])
}

for (const value of arr) {
    console.log(value);
}

console.log('-----------------------')

arr = [[2, 3, 4], [4, 5, 6], [5, 6]];
for (let j = 0; j < arr.length; j++) {
    for (let k = 0; k < arr[j].length; k++) {
        console.log(arr[j][k]);
    }
}
console.log('-----------------------')

for (const innerarr of arr) {
    for (const number of innerarr) {
        console.log(number);
    }
}
console.log('-----------------------')

let a = 2;
let b = a;
a = 1;
console.log(b);

console.log('-----------------------')

function handle_message(message) {
    console.log(`message is ${message}`)
}
// handle_message('hello')

// setTimeout(handle_message,3000,'hello'); // 暂停3秒

// setTimeout(()=>handle_message('world'), 3000);
// setTimeout(()=>setTimeout(console.log,3000, 'hello'),10);

// todo 函数回调
function callback(func) {
    return func();
}

function add(x,y) {
    return x+y;
}

console.log(callback((x,y)=>add(2**4,5))); // =>21
// console.log(callback(add)); // 这样传入add，无法给add传参.

function callback2(func,params) {
    return func(params);
}

console.log(callback2(add, [1,2]));

