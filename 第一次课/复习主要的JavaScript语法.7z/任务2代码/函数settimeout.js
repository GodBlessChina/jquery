setTimeout(function () {
    console.log('timeout 2222')
    console.log('22222222')
}, 2000)
setTimeout(function () {
    console.log('timeout 1111')
    console.log('1111111')
}, 1000)
setTimeout(function () {
    console.log('timeout() 00000')
}, 0)

function fn() {
    console.log('fn()')
}
fn()

console.log('主线程之前')
console.log('---主线程执行---') //暂停当前主线程的执行, 同时暂停计时, 点击确定后, 恢复程序执行和计时
console.log('主线程之后')
