/*
new Promise(function (resolve, reject){
    console.log('1');
    allr();
    // throw 'throw exception';
}).then(function (){
    console.log('2');
}).then(function (){
    console.log('3');
}).catch(function (err) { // todo 抓住异常信息。这里没什么逻辑性，完全是靠记忆或猜测，令人恶心。
    console.log('catch' + err);
}).finally(function (){
    console.log('finally');
}).then(function (){
    console.log('4');
});
*/

/*

new Promise(function () {
    setTimeout(()=>{
        console.log('异步执行 1');
    }, 3000);
}).then(function () {
    setTimeout(()=>{
        console.log('异步执行 2');
    }, 3000);
}).then(function () {
    setTimeout(()=>{
        console.log('异步执行 3');
    }, 3000);
});
*/
