function f1() {
    console.log('无参数 无返回值')
}
f1();

console.log('------------------------')

/**
 *
 * @param s1 String
 * @param s2
 */
function f2(s1, s2) {
    console.log('有参数 无返回值' + s1);
}
f2('hello','world');

console.log('------------------------')

function f3(s1) {
    console.log('有参数 有返回值')
    return 3 + s1;
}

console.log(f3('hello'));

console.log('------------------------')

// 匿名函数 1
let f4 = function () {
    console.log('无参数的匿名函数');
}

f4();

console.log('------------------------');

// 函数的定义
let f7 = function ff(s1){
    return s1;
}
console.log(f7('world'));

console.log('------------------------');
// 函数的定义 *** todo 一般推荐使用这种方式
// 匿名函数 2
let f5 = function (s1) {
    console.log('有参数的匿名函数' + s1);
}

f5('hello');

console.log('------------------------');

let f6 = function (s2) {
    return s2;
}

console.log( '有参数有返回值的匿名函数' + f6('hello'));

console.log('------------------------');

// 有参数有返回值的匿名函数 TODO
let f8 = (i1, i2)=>{
    return i1 * i2;
}

console.log(f8(2,5));

console.log('------------------------');

// 只有一个参数的匿名函数，括号可以不写
let f9 = i => {
    return i**2;
}
console.log(f9(5));

console.log('------------------------');

// 函数作为参数
let f10 = (func,parm)=>{
    return func(parm) * 2;
}

console.log(f10(f9, 6));
