// == 和 ===
// == 之比较"转化成同一类型后的值" 看"值" 是否相等，=== 如果类型不同，其结果就是不等。
console.log("true == '1':" + (true == '1')) // true.
console.log("true === '1': " + (true === '1')) // false.

// 强转
console.log("'1'转换成Boolean:" + Boolean('1')); // true 。 将 '1'转换成了true
console.log('1转换成Boolean:' + Boolean(1));// true 。 将 1转换成了true
console.log('0转换成Boolean:' + Boolean(0));// false 。 将 0转换成了false
console.log('字符串"hello"转换成Boolean:' + (Boolean("hello")))
console.log('空字符串""转换成Boolean:' + (Boolean("")))
console.log('[]转换成number:' + Number([]));// 0

// ~ 取反
// 按位非 NOT (en-US)	~ a	反转被操作数的位。  ~3 = 3的补码的补码
/**
 3 = 0000 0101
 3的补码 = 1111 1010 这是一个负数
 3的补码(负数)的补码 是 上面的数取反后+1 = 1000 0101 + 1
 ~3 = 1000 0101 + 1 = 1000 0110 = -4
 */
console.log("~[]的值是:" + ~[]); // -1


// 位移
console.log(6<<1);
const a = 5;          //  00000000000000000000000000000101
const b = 2;          //  00000000000000000000000000000010
const c = -5;         //  11111111111111111111111111111011  -5 = 5取反+1

console.log(a >>> b); //  00000000000000000000000000000001
// Expected output: 1

console.log(c >>> b); //  00111111111111111111111111111110
// Expected output: 1073741822

console.log((17).toString(16)); // radix是进制的意思

