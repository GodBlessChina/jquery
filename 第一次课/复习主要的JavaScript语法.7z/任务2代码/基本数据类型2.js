let s1 = 'hello'
let s2 = 'world'
console.log(typeof s1)
console.log(s1.pro)

/**
 *
 * @param str1
 * @param str2
 */
function f(str1, str2) {

}