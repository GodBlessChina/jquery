/*

class MyString extends String{
    constructor() {
        super();
    }

    format  = function () {
        console.log('format');
    }
}

/!**
 * 打印
 * @param {String} str
 *!/
let print = function(str) {
    reg = '{(.*)}'
    let matchAll = str.matchAll(reg);
    value = matchAll.next().value
    if (value === undefined)
    {
        console.log(str);
        return;
    }
    console.log('符合正则');

    str = MyString(str)

    this.format = function () {

    }
}

print('world')
print('{hello} {world}')

*/
/*

let person = {
    syaName (name){
        console.log('name is ${name}');
    }
};

person.syaName('张三');


let name = 'zhangsan';
console.log('name is ${name}');*/

// js中的对象是 python中的字典，这么理解就简单一些
/*
let person = {};
person.name = 'nic';
person.age = 19;
person.sayName = function (){
    console.log(this.name);
    // return this.name;
}

person.sayName();
*/

