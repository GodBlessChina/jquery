let names = {
    'fname':'dillion',
    'lname':'nic'
}

names.mname = 'xiaoxiao'; // 添加属性

console.log(names.toString());
console.log(names.fname)

console.log(names.hasOwnProperty('mname')); // 判断是否存在某个属性
console.log(names.mname)


// let x = 16 + "Volvo";
// let x = "16" + "Volvo";
// console.log(x)

let x;       // Now x is undefined
console.log(x)
x = 5;       // Now x is a Number
console.log(x)
x = "John";  // Now x is a String
console.log(x)