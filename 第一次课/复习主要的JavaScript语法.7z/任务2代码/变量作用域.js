// todo 作用域  a > b > c
//     a = '';
// var b = '';
// let c = ''; // 所以尽量使用let

function f1() {
    var a = 1;

    // todo 放f1被调用后 b变成一个全局变量。 f1不执行的话，b不存在undefined.
    b = function (){
        return a += 1;
    }

    function f2() {
        console.log(a);
    }

    return f2;
}

//// todo 这种情况下， f1()() 是一个新对象
// f1()(); // 1  这个f1()是个新function对象
// b();
// f1()(); // 1  这个f1()是个新function对象

//// todo 这种情况下， res是f1()执行后的同一个对象
var res = f1();
res();
b();
res();


