//var 声明是全局作用域或函数作用域，
// 而 let 和 const 是块作用域。
// var 变量可以在其范围内更新和重新声明；
// let 变量可以被更新但不能重新声明；
// const 变量既不能更新也不能重新声明。
//
// 它们都被提升到其作用域的顶端

a = 1
a = 2

var b = 3;
var b = 4; // 可以重新申明
b = 5; // 可以修改值。

let c = 5;
// let c = 6; // 不可以重复申明 ，报错SyntaxError: Identifier 'c' has already been declared
c = 6 // 能修改

const d = 7;
// const d = 8; // 不可以重复申明 ，报错SyntaxError: Identifier 'd' has already been declared
// d = 9; // 不能修改


let f = function () {
    i = 2; // 全局 第38行可以访问  如果是let i = 2就不能访问。
    /*return function () {
        return i**2;
    }();*/
    return ()=>{
        return i**2;
    }
}


console.log(f()());

console.log(i);