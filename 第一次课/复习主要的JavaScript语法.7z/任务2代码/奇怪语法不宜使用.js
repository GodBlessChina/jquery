// 1 不要使用 ==
console.log(0 == '')
console.log(false == 'false')
console.log(null == undefined)
console.log(null === undefined)

// 2 不要使用with
class Person {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
}

let person = new Person('jack', 19)
// person.xingming = person.name
// person.nianling = person.age
with (person) {
    nianling = age;
    xingming = name;
}
console.log(person.nianling, person.xingming)

// 3 不要在switch中忽略break
let i = 1;
switch (i) {
    case 1:
        console.log('1...');
        break;
    case 2:
        console.log('2...');
        break;
}

// 4 if for while 不能忽略花括号{}
if (i===1){
    console.log('yes');
}

for (let j = 0; j < 10; j++) {
    console.log("");
}


// function语句
//
// 在Javascript中定义一个函数，有两种写法：
//
// 　　function foo() { }
//
// 和
//
// 　　var foo = function () { }
//
// 两种写法完全等价。但是在解析的时候，前一种写法会被解析器自动提升到代码的头部，因此违背了函数应该先定义后使用的要求，
// todo 所以建议定义函数时，全部采用后一种写法。
let say = function (something) {
    console.log('say' + something);
}
say('hello world');